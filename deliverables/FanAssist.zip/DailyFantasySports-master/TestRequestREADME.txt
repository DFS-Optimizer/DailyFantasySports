Youtube video on implementation: https://www.youtube.com/watch?v=iwyK9S9yMgs
Source of example app Github: https://github.com/discospiff/PlantPlaces15s305/tree/master/app/src/main/java/nw15s305/plantplaces/com



Need:

-To tailor to our app UI to determine on what action(MainActivity) do these classes run.
-Replace Uri value to corresponding IP or url we will be requested from
